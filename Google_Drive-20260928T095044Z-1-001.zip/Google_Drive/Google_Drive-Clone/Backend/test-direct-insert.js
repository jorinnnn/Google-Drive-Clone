require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

console.log('🔧 Testing direct database insert\n');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

async function testDirectInsert() {
  try {
    console.log('1. Testing direct user insert...');
    
    // Try to insert a user directly
    const { data, error } = await supabase
      .from('users')
      .insert({
        name: 'Direct Test',
        email: `direct${Date.now()}@test.com`,
        password_hash: 'temp_hash_for_testing',
        storage_used: 0,
        storage_limit: 16106127360
      })
      .select();
    
    if (error) {
      console.log('❌ Direct insert error:', error.message);
      console.log('Details:', error.details);
      console.log('Hint:', error.hint);
      console.log('\n💡 This confirms RLS is blocking inserts');
    } else {
      console.log('✅ Direct insert successful!');
      console.log('Inserted user:', data[0].email);
      
      // Clean up
      await supabase.from('users').delete().eq('email', data[0].email);
    }
    
  } catch (err) {
    console.log('❌ Error:', err.message);
  }
}

testDirectInsert();