require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

console.log('🚀 Simple Supabase Setup for Google Drive Clone');
console.log('===============================================\n');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase credentials in .env file');
  console.error('Please add:');
  console.error('SUPABASE_URL=https://ysywxnuwwvjzdsosvbzz.supabase.co');
  console.error('SUPABASE_ANON_KEY=your_anon_key_here');
  process.exit(1);
}

console.log('📊 Supabase Project:', supabaseUrl);
console.log('🔑 Using Anon Key:', supabaseKey.substring(0, 10) + '...');

const supabase = createClient(supabaseUrl, supabaseKey);

async function setup() {
  console.log('\n📝 Copy and run this SQL in Supabase SQL Editor:\n');
  
  const sql = `
-- ============================================
-- Google Drive Clone - Database Setup
-- ============================================

-- 1. Create Users Table
CREATE TABLE IF NOT EXISTS users (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    storage_used BIGINT DEFAULT 0,
    storage_limit BIGINT DEFAULT 16106127360, -- 15GB
    avatar_url TEXT,
    is_verified BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Create Folders Table
CREATE TABLE IF NOT EXISTS folders (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
    parent_folder_id UUID REFERENCES folders(id) ON DELETE SET NULL,
    path TEXT NOT NULL,
    is_starred BOOLEAN DEFAULT false,
    is_trashed BOOLEAN DEFAULT false,
    color VARCHAR(7) DEFAULT '#4285F4',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Create Files Table
CREATE TABLE IF NOT EXISTS files (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    filename VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    size BIGINT NOT NULL,
    path TEXT NOT NULL,
    storage_url TEXT,
    owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
    folder_id UUID REFERENCES folders(id) ON DELETE SET NULL,
    is_starred BOOLEAN DEFAULT false,
    is_trashed BOOLEAN DEFAULT false,
    checksum VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Create File Shares Table
CREATE TABLE IF NOT EXISTS file_shares (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    file_id UUID REFERENCES files(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    permission VARCHAR(10) CHECK (permission IN ('view', 'edit')),
    shared_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(file_id, user_id)
);

-- 5. Create Indexes for Better Performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_folders_owner ON folders(owner_id);
CREATE INDEX IF NOT EXISTS idx_files_owner ON files(owner_id);
CREATE INDEX IF NOT EXISTS idx_files_folder ON files(folder_id);

-- 6. Create Admin User (password: admin123)
INSERT INTO users (name, email, password_hash, is_verified) 
VALUES ('Admin User', 'admin@example.com', '\\$2a\\$10\\$placeholder_hash_change_this_in_production', true)
ON CONFLICT (email) DO NOTHING;

-- 7. Create Updated At Trigger Function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS \\$\\$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
\\$\\$ language 'plpgsql';

-- 8. Create Triggers
CREATE TRIGGER update_users_updated_at 
    BEFORE UPDATE ON users 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_files_updated_at 
    BEFORE UPDATE ON files 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_folders_updated_at 
    BEFORE UPDATE ON folders 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- Setup Complete!
-- ============================================
`;

  console.log(sql);
  
  console.log('\n📋 Manual Setup Instructions:');
  console.log('1. Go to Supabase Dashboard → SQL Editor');
  console.log('2. Copy and paste the SQL above');
  console.log('3. Click "Run" to execute');
  console.log('4. Create storage buckets manually:');
  console.log('   - Go to Storage → Create Bucket');
  console.log('   - Create: files, avatars, thumbnails');
  console.log('   - Set avatars and thumbnails as public');
  
  // Test connection
  console.log('\n🔌 Testing connection to Supabase...');
  try {
    const { data, error } = await supabase.from('users').select('count').limit(1);
    
    if (error && error.code === 'PGRST116') {
      console.log('✅ Connection successful! Tables need to be created.');
    } else if (error) {
      console.log('⚠️  Connection issue:', error.message);
    } else {
      console.log('✅ Connection successful! Tables already exist.');
    }
  } catch (err) {
    console.log('❌ Connection failed:', err.message);
  }
}

setup();