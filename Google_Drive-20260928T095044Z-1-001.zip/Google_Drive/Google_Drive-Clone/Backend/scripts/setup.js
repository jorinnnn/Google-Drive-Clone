require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

console.log('🚀 Google Drive Clone - Database Setup');
console.log('======================================\n');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase credentials in .env file');
  console.error('Please add:');
  console.error('SUPABASE_URL=https://ysywxnuwwvjzdsosvbzz.supabase.co');
  console.error('SUPABASE_ANON_KEY=your_anon_key_here');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function setupDatabase() {
  console.log('📋 Manual Setup Instructions:');
  console.log('1. Go to: https://ysywxnuwwvjzdsosvbzz.supabase.co');
  console.log('2. Click on "SQL Editor" in the sidebar');
  console.log('3. Create a new query');
  console.log('4. Copy and paste the SQL below');
  console.log('5. Click "Run" to execute\n');
  
  console.log('📝 SQL to run in Supabase SQL Editor:\n');
  
  const sql = `
-- Google Drive Clone Database Setup
-- Run this in Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Users Table
CREATE TABLE users (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    storage_used BIGINT DEFAULT 0,
    storage_limit BIGINT DEFAULT 16106127360, -- 15GB
    avatar_url TEXT,
    is_verified BOOLEAN DEFAULT false,
    last_login TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Files Table
CREATE TABLE files (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    filename VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    size BIGINT NOT NULL,
    path TEXT NOT NULL,
    owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
    folder_id UUID REFERENCES folders(id) ON DELETE SET NULL,
    is_starred BOOLEAN DEFAULT false,
    is_trashed BOOLEAN DEFAULT false,
    checksum VARCHAR(64),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Create Indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_files_owner_id ON files(owner_id);

-- 4. Insert Admin User (password: admin123)
-- Note: You need to hash the password in your app
INSERT INTO users (name, email, password_hash, is_verified) 
VALUES ('Admin User', 'admin@example.com', '\\$2a\\$10\\$placeholder_hash_change_this_in_production', true)
ON CONFLICT (email) DO NOTHING;

-- 5. Create function to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- 6. Create triggers
CREATE TRIGGER update_users_updated_at 
    BEFORE UPDATE ON users 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_files_updated_at 
    BEFORE UPDATE ON files 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

SELECT '✅ Google Drive Clone database setup complete!' as message;
`;

  console.log(sql);
  
  console.log('\n📦 Storage Setup:');
  console.log('1. Go to Supabase → Storage');
  console.log('2. Click "New Bucket"');
  console.log('3. Create bucket: "files" (private)');
  console.log('4. Create bucket: "avatars" (public)');
  
  // Test connection
  console.log('\n🔌 Testing connection...');
  try {
    const { error } = await supabase.from('users').select('count').limit(1);
    
    if (error && error.code === 'PGRST116') {
      console.log('✅ Connection successful! Tables need to be created.');
    } else if (error) {
      console.log('⚠️  Connection issue:', error.message);
    } else {
      console.log('✅ Connection successful!');
    }
  } catch (err) {
    console.log('❌ Connection failed:', err.message);
  }
}

setupDatabase();