require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Missing Supabase configuration');
  console.error('Please set SUPABASE_URL and SUPABASE_SERVICE_KEY in .env file');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

async function setupDatabase() {
  console.log('🚀 Setting up Google Drive Clone database on Supabase...');
  console.log('📊 Project URL:', supabaseUrl);

  try {
    // 1. Create tables
    console.log('\n📋 Creating tables...');
    
    const tablesSQL = `
    -- Users table
    CREATE TABLE IF NOT EXISTS users (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        storage_used BIGINT DEFAULT 0,
        storage_limit BIGINT DEFAULT 16106127360,
        avatar_url TEXT,
        is_verified BOOLEAN DEFAULT false,
        two_factor_secret VARCHAR(255),
        two_factor_enabled BOOLEAN DEFAULT false,
        last_login TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    -- Folders table
    CREATE TABLE IF NOT EXISTS folders (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
        parent_folder_id UUID REFERENCES folders(id) ON DELETE SET NULL,
        path TEXT NOT NULL,
        is_starred BOOLEAN DEFAULT false,
        is_trashed BOOLEAN DEFAULT false,
        trashed_at TIMESTAMP WITH TIME ZONE,
        color VARCHAR(7) DEFAULT '#4285F4',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    -- Files table
    CREATE TABLE IF NOT EXISTS files (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        filename VARCHAR(255) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        mime_type VARCHAR(100) NOT NULL,
        size BIGINT NOT NULL,
        path TEXT NOT NULL,
        storage_url TEXT,
        owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
        folder_id UUID REFERENCES folders(id) ON DELETE SET NULL,
        is_starred BOOLEAN DEFAULT false,
        is_trashed BOOLEAN DEFAULT false,
        trashed_at TIMESTAMP WITH TIME ZONE,
        checksum VARCHAR(64),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    -- File shares table
    CREATE TABLE IF NOT EXISTS file_shares (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        file_id UUID REFERENCES files(id) ON DELETE CASCADE,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        permission VARCHAR(10) CHECK (permission IN ('view', 'edit')),
        shared_by UUID REFERENCES users(id),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        UNIQUE(file_id, user_id)
    );

    -- File versions table
    CREATE TABLE IF NOT EXISTS file_versions (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        file_id UUID REFERENCES files(id) ON DELETE CASCADE,
        version_number INTEGER NOT NULL,
        filename VARCHAR(255) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        mime_type VARCHAR(100) NOT NULL,
        size BIGINT NOT NULL,
        path TEXT NOT NULL,
        storage_url TEXT,
        checksum VARCHAR(64),
        created_by UUID REFERENCES users(id),
        changes TEXT,
        is_auto_saved BOOLEAN DEFAULT false,
        metadata JSONB DEFAULT '{}'::jsonb,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        UNIQUE(file_id, version_number)
    );

    -- Notifications table
    CREATE TABLE IF NOT EXISTS notifications (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        type VARCHAR(50) NOT NULL,
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        data JSONB DEFAULT '{}'::jsonb,
        is_read BOOLEAN DEFAULT false,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
    `;

    // Execute the SQL
    const { error } = await supabase.rpc('exec_sql', { sql: tablesSQL });
    
    if (error) {
      console.log('ℹ️  Note: Some tables might already exist');
    } else {
      console.log('✅ Tables created successfully');
    }

    // 2. Create indexes
    console.log('\n🔍 Creating indexes...');
    
    const indexesSQL = `
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_folders_owner_id ON folders(owner_id);
    CREATE INDEX IF NOT EXISTS idx_folders_parent_id ON folders(parent_folder_id);
    CREATE INDEX IF NOT EXISTS idx_files_owner_id ON files(owner_id);
    CREATE INDEX IF NOT EXISTS idx_files_folder_id ON files(folder_id);
    CREATE INDEX IF NOT EXISTS idx_files_trashed ON files(is_trashed);
    CREATE INDEX IF NOT EXISTS idx_file_shares_file_id ON file_shares(file_id);
    CREATE INDEX IF NOT EXISTS idx_file_shares_user_id ON file_shares(user_id);
    CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
    CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
    `;

    await supabase.rpc('exec_sql', { sql: indexesSQL });
    console.log('✅ Indexes created');

    // 3. Create storage buckets
    console.log('\n📦 Creating storage buckets...');
    
    const buckets = [
      { name: 'files', public: false },
      { name: 'avatars', public: true },
      { name: 'thumbnails', public: true }
    ];

    for (const bucket of buckets) {
      try {
        const { error } = await supabase.storage.createBucket(bucket.name, {
          public: bucket.public,
          fileSizeLimit: bucket.name === 'files' ? 104857600 : 5242880
        });

        if (error) {
          if (error.message.includes('already exists')) {
            console.log(`✅ Bucket "${bucket.name}" already exists`);
          } else {
            console.log(`⚠️  Could not create bucket "${bucket.name}":`, error.message);
          }
        } else {
          console.log(`✅ Created bucket: "${bucket.name}"`);
        }
      } catch (err) {
        console.log(`⚠️  Error with bucket "${bucket.name}":`, err.message);
      }
    }

    // 4. Create functions
    console.log('\n⚙️  Creating database functions...');
    
    const functionsSQL = `
    -- Function to update updated_at timestamp
    CREATE OR REPLACE FUNCTION update_updated_at_column()
    RETURNS TRIGGER AS $$
    BEGIN
        NEW.updated_at = NOW();
        RETURN NEW;
    END;
    $$ language 'plpgsql';

    -- Function to get user storage usage
    CREATE OR REPLACE FUNCTION get_user_storage_usage(user_uuid UUID)
    RETURNS TABLE(total_used BIGINT, storage_limit BIGINT, percentage_used NUMERIC) AS $$
    BEGIN
        RETURN QUERY
        SELECT 
            COALESCE(SUM(f.size), 0) as total_used,
            u.storage_limit,
            CASE 
                WHEN u.storage_limit > 0 
                THEN ROUND((COALESCE(SUM(f.size), 0)::NUMERIC / u.storage_limit::NUMERIC) * 100, 2)
                ELSE 0 
            END as percentage_used
        FROM users u
        LEFT JOIN files f ON u.id = f.owner_id AND f.is_trashed = false
        WHERE u.id = user_uuid
        GROUP BY u.id, u.storage_limit;
    END;
    $$ LANGUAGE plpgsql;

    -- Function to check file permissions
    CREATE OR REPLACE FUNCTION check_file_permission(
        file_uuid UUID,
        user_uuid UUID,
        required_permission VARCHAR
    )
    RETURNS BOOLEAN AS $$
    DECLARE
        file_owner UUID;
        has_share_permission BOOLEAN;
    BEGIN
        -- Get file owner
        SELECT owner_id INTO file_owner FROM files WHERE id = file_uuid;
        
        -- If user is the owner
        IF file_owner = user_uuid THEN
            RETURN TRUE;
        END IF;
        
        -- Check shared permissions
        IF required_permission = 'view' THEN
            SELECT EXISTS(
                SELECT 1 FROM file_shares 
                WHERE file_id = file_uuid 
                AND user_id = user_uuid 
                AND permission IN ('view', 'edit')
            ) INTO has_share_permission;
        ELSE
            SELECT EXISTS(
                SELECT 1 FROM file_shares 
                WHERE file_id = file_uuid 
                AND user_id = user_uuid 
                AND permission = 'edit'
            ) INTO has_share_permission;
        END IF;
        
        RETURN has_share_permission;
    END;
    $$ LANGUAGE plpgsql;
    `;

    await supabase.rpc('exec_sql', { sql: functionsSQL });
    console.log('✅ Functions created');

    // 5. Create triggers
    console.log('\n🎯 Creating triggers...');
    
    const triggersSQL = `
    CREATE TRIGGER update_users_updated_at 
        BEFORE UPDATE ON users 
        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

    CREATE TRIGGER update_files_updated_at 
        BEFORE UPDATE ON files 
        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

    CREATE TRIGGER update_folders_updated_at 
        BEFORE UPDATE ON folders 
        FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    `;

    await supabase.rpc('exec_sql', { sql: triggersSQL });
    console.log('✅ Triggers created');

    // 6. Create admin user
    console.log('\n👤 Creating admin user...');
    
    const adminEmail = 'admin@example.com';
    const adminPassword = 'admin123';
    
    // Check if admin already exists
    const { data: existingAdmin } = await supabase
      .from('users')
      .select('id')
      .eq('email', adminEmail)
      .single();

    if (!existingAdmin) {
      // In a real app, you should hash the password properly
      // For now, we'll create a placeholder
      const { error: insertError } = await supabase
        .from('users')
        .insert({
          name: 'Admin User',
          email: adminEmail,
          password_hash: 'placeholder_hash_change_in_production',
          is_verified: true
        });

      if (insertError) {
        console.log('⚠️  Could not create admin user:', insertError.message);
      } else {
        console.log('✅ Admin user created');
        console.log('   Email:', adminEmail);
        console.log('   Password:', adminPassword);
        console.log('   ⚠️  IMPORTANT: Update password_hash in database with bcrypt hash!');
      }
    } else {
      console.log('✅ Admin user already exists');
    }

    console.log('\n🎉 Database setup completed successfully!');
    console.log('\n📋 Next steps:');
    console.log('1. Install dependencies: npm install');
    console.log('2. Start backend server: npm run dev');
    console.log('3. Access API at: http://localhost:5000');
    console.log('\n🔧 To manually execute SQL, go to:');
    console.log('   Supabase Dashboard → SQL Editor');

  } catch (error) {
    console.error('❌ Setup failed:', error.message);
    console.error('\n💡 Troubleshooting tips:');
    console.error('1. Check your Supabase credentials in .env file');
    console.error('2. Ensure you have Service Role key (not anon key)');
    console.error('3. Check if exec_sql function exists in Supabase');
    
    // If exec_sql doesn't exist, provide manual setup instructions
    console.error('\n📝 Manual setup required:');
    console.error('1. Go to Supabase Dashboard → SQL Editor');
    console.error('2. Run the SQL statements from the setup script manually');
    console.error('3. Create storage buckets manually in Storage section');
  }
}

// Check if exec_sql function exists, if not create it
async function ensureExecSqlFunction() {
  try {
    // Try to call exec_sql
    await supabase.rpc('exec_sql', { sql: 'SELECT 1' });
    return true;
  } catch (error) {
    console.log('Creating exec_sql function...');
    
    // Create exec_sql function
    const createFunctionSQL = `
    CREATE OR REPLACE FUNCTION exec_sql(sql TEXT)
    RETURNS VOID AS $$
    BEGIN
        EXECUTE sql;
    END;
    $$ LANGUAGE plpgsql SECURITY DEFINER;
    `;

    // We need to use a different approach since exec_sql doesn't exist yet
    const { error: createError } = await supabase
      .from('_exec_sql_temp')
      .select('*')
      .limit(1);

    if (createError && createError.message.includes('does not exist')) {
      console.log('⚠️  exec_sql function does not exist and cannot be created automatically');
      console.log('💡 Please create it manually in Supabase SQL Editor:');
      console.log(createFunctionSQL);
      return false;
    }
    
    return true;
  }
}

// First, ensure exec_sql function exists
ensureExecSqlFunction().then(hasFunction => {
  if (hasFunction) {
    setupDatabase();
  } else {
    console.log('\n📝 Please create the exec_sql function manually, then run setup again.');
  }
});