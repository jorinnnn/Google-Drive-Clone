require('dotenv').config();
const axios = require('axios');

const API_URL = 'http://localhost:5000/api';

async function createTestUser() {
  console.log('👤 Creating test user...\n');
  
  const userData = {
    name: 'Test User',
    email: 'test@example.com',
    password: 'password123'
  };
  
  try {
    // Try to register
    console.log('1. Attempting to register user...');
    const registerRes = await axios.post(`${API_URL}/auth/register`, userData);
    
    console.log('✅ User created successfully!');
    console.log('   User ID:', registerRes.data.user.id);
    console.log('   Token:', registerRes.data.token.substring(0, 20) + '...\n');
    
    return {
      token: registerRes.data.token,
      userId: registerRes.data.user.id
    };
    
  } catch (error) {
    if (error.response?.data?.message?.includes('already exists')) {
      console.log('ℹ️  User already exists, trying login...\n');
      
      // Try to login
      const loginRes = await axios.post(`${API_URL}/auth/login`, {
        email: userData.email,
        password: userData.password
      });
      
      console.log('✅ Login successful!');
      console.log('   User ID:', loginRes.data.user.id);
      console.log('   Token:', loginRes.data.token.substring(0, 20) + '...\n');
      
      return {
        token: loginRes.data.token,
        userId: loginRes.data.user.id
      };
    } else {
      console.error('❌ Error:', error.response?.data || error.message);
      return null;
    }
  }
}

// Run the function
createTestUser().then(result => {
  if (result) {
    console.log('🎉 Test user ready!');
    console.log('Use this token for API requests:');
    console.log('Authorization: Bearer ' + result.token.substring(0, 20) + '...');
  } else {
    console.log('❌ Failed to create/get test user');
  }
});