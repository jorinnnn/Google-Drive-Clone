require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

console.log('🔑 Testing Supabase Connection with JWT Token\n');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

console.log('URL:', supabaseUrl);
console.log('Key starts with:', supabaseKey.substring(0, 30) + '...');
console.log('Key length:', supabaseKey.length);
console.log('Key type:', supabaseKey.startsWith('eyJ') ? '✅ JWT Token (Correct)' : '❌ Wrong format');

const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

console.log('\n📡 Testing database connection...');

supabase.from('users').select('count').limit(1)
  .then(({ data, error }) => {
    if (error) {
      if (error.code === 'PGRST116') {
        console.log('✅ Connection successful!');
        console.log('ℹ️  Tables do not exist yet (or empty)');
        console.log('💡 This is OK - tables will be created when you use the API');
      } else {
        console.log('❌ Error:', error.message);
        console.log('Code:', error.code);
      }
    } else {
      console.log('✅ Connection successful!');
      console.log('📊 Database is accessible');
    }
  })
  .catch(err => {
    console.log('❌ Connection failed:', err.message);
  });