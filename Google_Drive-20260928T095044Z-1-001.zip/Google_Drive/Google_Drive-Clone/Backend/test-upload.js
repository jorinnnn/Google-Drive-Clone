require('dotenv').config();
const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');

const API_URL = 'http://localhost:5000/api';

async function testUpload() {
  console.log('📤 Testing file upload to Supabase Storage\n');
  
  // Create a test file
  const testContent = 'This is a test file for Google Drive Clone\nCreated at: ' + new Date().toISOString();
  fs.writeFileSync('test-upload.txt', testContent);
  
  try {
    // 1. Login
    console.log('1. Logging in...');
    const loginRes = await axios.post(`${API_URL}/auth/login`, {
      email: 'test@example.com',
      password: 'password123'
    });
    
    const token = loginRes.data.token;
    console.log('   ✅ Logged in, token:', token.substring(0, 20) + '...\n');
    
    // 2. Upload file
    console.log('2. Uploading test file...');
    
    const formData = new FormData();
    formData.append('file', fs.createReadStream('test-upload.txt'));
    
    const uploadRes = await axios.post(`${API_URL}/files/upload`, formData, {
      headers: {
        'Authorization': `Bearer ${token}`,
        ...formData.getHeaders()
      },
      maxContentLength: Infinity,
      maxBodyLength: Infinity
    });
    
    console.log('   ✅ File uploaded successfully!');
    console.log('   File ID:', uploadRes.data.file.id);
    console.log('   Original name:', uploadRes.data.file.original_name);
    console.log('   Storage:', uploadRes.data.storage);
    console.log('   Size:', uploadRes.data.file.size, 'bytes\n');
    
    // 3. List files
    console.log('3. Listing user files...');
    const filesRes = await axios.get(`${API_URL}/files`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    console.log('   Total files:', filesRes.data.files.length);
    filesRes.data.files.forEach((file, index) => {
      console.log(`   ${index + 1}. ${file.original_name} (${file.size} bytes)`);
    });
    
    // 4. Clean up test file
    fs.unlinkSync('test-upload.txt');
    
    console.log('\n🎉 File upload test completed successfully!');
    console.log('\n📋 Next: Check your Supabase Storage:');
    console.log('1. Go to https://htlbkrjzwsbtkrrmpwhs.supabase.co');
    console.log('2. Click "Storage"');
    console.log('3. Click "files" bucket');
    console.log('4. You should see your uploaded file');
    
  } catch (error) {
    console.error('\n❌ Test failed:');
    console.error('   Message:', error.response?.data?.message || error.message);
    console.error('   Error:', error.response?.data?.error || error.response?.data);
    
    // Clean up
    if (fs.existsSync('test-upload.txt')) {
      fs.unlinkSync('test-upload.txt');
    }
  }
}

// Install form-data if not installed
console.log('Note: Install form-data if needed: npm install form-data');
testUpload();
