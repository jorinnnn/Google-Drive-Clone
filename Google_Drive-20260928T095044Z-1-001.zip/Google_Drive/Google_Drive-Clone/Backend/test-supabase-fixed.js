// test-supabase-fixed.js - CommonJS style
console.log('🔌 Testing Supabase Connection (CommonJS)\n');

// Load environment
require('dotenv').config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

console.log('Project URL:', supabaseUrl);
console.log('Anon Key:', supabaseKey ? '✓ Present' : '✗ Missing');

if (!supabaseUrl || !supabaseKey) {
  console.error('\n❌ Missing credentials in .env file');
  console.error('Please check your .env file');
  process.exit(1);
}

// Test in async function to avoid top-level await
async function runTest() {
  try {
    const { createClient } = require('@supabase/supabase-js');
    console.log('\n✅ @supabase/supabase-js module loaded');
    
    const supabase = createClient(supabaseUrl, supabaseKey);
    console.log('✅ Supabase client created');
    
    // Test connection
    console.log('\n📡 Testing database connection...');
    const { data, error } = await supabase.from('users').select('count').limit(1);
    
    if (error) {
      if (error.code === 'PGRST116') {
        console.log('✅ Connection successful!');
        console.log('ℹ️  Tables do not exist yet - run the setup SQL');
      } else {
        console.error('❌ Connection error:', error.message);
        console.error('Error code:', error.code);
      }
    } else {
      console.log('✅ Connection successful!');
      console.log('📊 Tables exist');
    }
    
  } catch (error) {
    console.error('\n❌ Test failed:', error.message);
  }
}

// Run the test
runTest();