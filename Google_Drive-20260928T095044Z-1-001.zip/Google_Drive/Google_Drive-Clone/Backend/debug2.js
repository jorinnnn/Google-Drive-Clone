﻿console.log("=== STARTING DEBUG ===\n");

// 1. Show Node info
console.log("1. Node.js Info:");
console.log("   Version:", process.version);
console.log("   Platform:", process.platform);
console.log("   Arch:", process.arch);

// 2. Show environment
console.log("\n2. Environment:");
console.log("   NODE_ENV:", process.env.NODE_ENV || "not set");
console.log("   PORT:", process.env.PORT || "not set");
console.log("   Current directory:", process.cwd());

// 3. Try to load main app
console.log("\n3. Loading main app...");
try {
  // Try to load the app
  require('./src/app.js');
  console.log("   ✅ src/app.js loaded");
} catch (error) {
  console.log("   ❌ Error loading src/app.js:");
  console.log("   Message:", error.message);
  console.log("   Stack trace:");
  console.log(error.stack);
}

// 4. Check for missing modules
console.log("\n4. Checking for required modules...");
const modules = ['express', 'cors', 'dotenv', '@supabase/supabase-js'];
modules.forEach(moduleName => {
  try {
    require.resolve(moduleName);
    console.log(`   ✅ ${moduleName} is installed`);
  } catch (e) {
    console.log(`   ❌ ${moduleName} is NOT installed`);
  }
});

console.log("\n=== DEBUG COMPLETE ===");
