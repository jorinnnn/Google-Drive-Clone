// minimal.js - Simplest possible server
const http = require('http');

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ 
    message: 'Google Drive Clone API',
    status: 'running',
    timestamp: new Date().toISOString()
  }));
});

const PORT = 5000;
server.listen(PORT, () => {
  console.log(`✅ Simple server running on http://localhost:${PORT}`);
});

// Keep alive
console.log("Server started. Press Ctrl+C to stop.");