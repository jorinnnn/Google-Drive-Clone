﻿// Simple test to check Node.js is working
console.log("Node.js is working!");
console.log("Testing require statements...");

try {
  const express = require('express');
  console.log("✅ express loaded");

  const cors = require('cors');
  console.log("✅ cors loaded");

  const helmet = require('helmet');
  console.log("✅ helmet loaded");

  const dotenv = require('dotenv');
  console.log("✅ dotenv loaded");

  console.log("\n✅ All modules loaded successfully!");
} catch (error) {
  console.error("❌ Error loading module:", error.message);
  console.error("Stack:", error.stack);
}
