require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

console.log('🔑 Testing Supabase API Key\n');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

console.log('URL:', supabaseUrl);
console.log('Key starts with:', supabaseKey ? supabaseKey.substring(0, 50) + '...' : 'MISSING');
console.log('Key length:', supabaseKey ? supabaseKey.length : '0');

if (!supabaseKey || !supabaseKey.startsWith('eyJ')) {
  console.error('\n❌ Invalid API key format!');
  console.error('   Key should start with "eyJ" (JWT token)');
  console.error('   Get it from: Supabase → Settings → API → anon public key');
  process.exit(1);
}

try {
  const supabase = createClient(supabaseUrl, supabaseKey);
  console.log('\n✅ Supabase client created');
  
  // Test connection
  supabase.from('users').select('count').limit(1)
    .then(({ data, error }) => {
      if (error) {
        console.log('\n❌ API Key Error:', error.message);
        console.log('Code:', error.code);
        
        if (error.message.includes('Invalid API key')) {
          console.log('\n💡 Solutions:');
          console.log('1. Get a fresh key from Supabase → Settings → API');
          console.log('2. Make sure you copy the "anon" key (not service role)');
          console.log('3. Check if your project is active');
          console.log('4. Check network restrictions in Supabase');
        }
      } else {
        console.log('\n✅ API Key is valid!');
        console.log('Connection successful');
      }
    })
    .catch(err => {
      console.log('\n❌ Connection failed:', err.message);
    });
    
} catch (error) {
  console.error('\n❌ Client creation failed:', error.message);
}