const axios = require('axios');

const API_URL = 'http://localhost:5000/api';

async function debugAPI() {
  console.log('🔍 Debugging API Connection\n');
  
  // 1. Test server connection
  console.log('1. Testing server connection...');
  try {
    const response = await axios.get(`${API_URL}/health`, {
      timeout: 5000
    });
    console.log('   ✅ Server is running');
    console.log('   Response:', JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.log('   ❌ Server not reachable');
    console.log('   Error:', error.message);
    console.log('   💡 Start server with: npm run dev');
    return;
  }
  
  console.log('\n2. Testing registration endpoint...');
  
  const userData = {
    name: 'Debug User',
    email: `debug${Date.now()}@example.com`,
    password: 'password123'
  };
  
  try {
    const response = await axios.post(`${API_URL}/auth/register`, userData, {
      timeout: 5000,
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    console.log('   ✅ Registration successful!');
    console.log('   Status:', response.status);
    console.log('   User ID:', response.data.user?.id);
    console.log('   Token exists:', !!response.data.token);
    
  } catch (error) {
    console.log('   ❌ Registration failed');
    console.log('   Status:', error.response?.status);
    console.log('   Error message:', error.response?.data?.message);
    console.log('   Full error:', JSON.stringify(error.response?.data, null, 2));
    
    if (error.response?.status === 500) {
      console.log('\n💡 Server error - check backend logs');
    }
  }
}

debugAPI();