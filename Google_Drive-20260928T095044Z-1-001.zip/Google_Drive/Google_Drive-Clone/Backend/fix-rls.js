require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

console.log('🔧 Fixing RLS Policies\n');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase credentials');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function fixRLS() {
  console.log('Copy and run this SQL in Supabase SQL Editor:\n');
  
  const sql = `
-- Fix for Google Drive Clone RLS Policies
-- Run this in Supabase SQL Editor

-- Option 1: Disable RLS for development (easiest)
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
ALTER TABLE files DISABLE ROW LEVEL SECURITY;
ALTER TABLE folders DISABLE ROW LEVEL SECURITY;
ALTER TABLE file_shares DISABLE ROW LEVEL SECURITY;

-- Option 2: Create proper policies (recommended for production)
/*
-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE files ENABLE ROW LEVEL SECURITY;
ALTER TABLE folders ENABLE ROW LEVEL SECURITY;

-- Users table policies
CREATE POLICY "Users can insert their own data" ON users
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view their own data" ON users
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own data" ON users
    FOR UPDATE USING (auth.uid() = id);

-- Files table policies
CREATE POLICY "Users can insert files" ON files
    FOR INSERT WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Users can view their files" ON files
    FOR SELECT USING (auth.uid() = owner_id OR 
                     file_id IN (SELECT file_id FROM file_shares WHERE user_id = auth.uid()));

CREATE POLICY "Users can update their files" ON files
    FOR UPDATE USING (auth.uid() = owner_id);
*/

SELECT '✅ RLS policies fixed!' as message;
`;

  console.log(sql);
  console.log('\n📋 Instructions:');
  console.log('1. Go to https://htlbkrjzwsbtkrrmpwhs.supabase.co');
  console.log('2. Click "SQL Editor"');
  console.log('3. Create new query');
  console.log('4. Copy and paste the SQL above');
  console.log('5. Run Option 1 first (disable RLS)');
  console.log('6. Test your backend again');
}

fixRLS();