require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

async function checkTables() {
  console.log('📊 Checking database tables...\n');
  
  const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_ANON_KEY
  );
  
  // Check each table
  const tables = ['users', 'files', 'folders', 'file_shares', 'file_versions', 'notifications'];
  
  for (const table of tables) {
    try {
      const { data, error } = await supabase.from(table).select('count').limit(1);
      
      if (error) {
        if (error.code === 'PGRST116') {
          console.log(`❌ ${table}: Table does not exist`);
        } else {
          console.log(`⚠️  ${table}: ${error.message}`);
        }
      } else {
        console.log(`✅ ${table}: Table exists`);
      }
    } catch (err) {
      console.log(`❌ ${table}: Error - ${err.message}`);
    }
  }
  
  // Check storage buckets
  console.log('\n📦 Checking storage buckets...');
  try {
    const { data: buckets, error } = await supabase.storage.listBuckets();
    if (error) {
      console.log('❌ Error checking buckets:', error.message);
    } else {
      const bucketNames = buckets.map(b => b.name);
      console.log('Available buckets:', bucketNames);
      
      const required = ['files', 'avatars'];
      required.forEach(bucket => {
        if (bucketNames.includes(bucket)) {
          console.log(`✅ ${bucket} bucket exists`);
        } else {
          console.log(`❌ ${bucket} bucket missing`);
        }
      });
    }
  } catch (err) {
    console.log('❌ Storage check failed:', err.message);
  }
}

checkTables();