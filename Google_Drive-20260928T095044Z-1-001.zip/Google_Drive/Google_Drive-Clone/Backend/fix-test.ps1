# fix-test.ps1 - Working PowerShell test
Write-Host "🔧 Testing Backend Registration" -ForegroundColor Cyan

# Method 1: Using ConvertTo-Json (most reliable)
try {
    $body = @{
        name = "PowerShell User"
        email = "psuser@example.com"
        password = "password123"
    }
    
    $json = $body | ConvertTo-Json
    
    Write-Host "Sending JSON:" -ForegroundColor Yellow
    Write-Host $json -ForegroundColor Gray
    
    $response = Invoke-RestMethod -Uri "http://localhost:5000/api/auth/register" `
        -Method Post `
        -ContentType "application/json" `
        -Body $json
    
    Write-Host "`n✅ SUCCESS!" -ForegroundColor Green
    Write-Host "Response:" -ForegroundColor Yellow
    $response | Format-List | Out-String | Write-Host
    
} catch {
    Write-Host "`n❌ ERROR:" -ForegroundColor Red
    Write-Host "Status Code: $($_.Exception.Response.StatusCode.value__)" -ForegroundColor Red
    Write-Host "Message: $($_.Exception.Message)" -ForegroundColor Red
    
    # Try to read error response
    try {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        $responseBody = $reader.ReadToEnd()
        Write-Host "Response Body: $responseBody" -ForegroundColor Red
    } catch {
        Write-Host "Could not read error response" -ForegroundColor Red
    }
}