const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const dotenv = require('dotenv');
const path = require('path');

// Load environment variables
dotenv.config();

// Import database
const { testConnection } = require('./config/database');

// Import routes
const authRoutes = require('./routes/auth');
const fileRoutes = require('./routes/files');

const app = express();

// Security middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100
});
app.use('/api/', limiter);

// Body parsing middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve static files
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/files', fileRoutes);

// Health check endpoint
app.get('/api/health', async (req, res) => {
  const dbConnected = await testConnection();
  
  res.status(200).json({
    status: 'OK',
    message: 'Google Drive Clone Backend',
    database: dbConnected ? 'Connected' : 'Disconnected',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    endpoints: {
      auth: '/api/auth',
      files: '/api/files'
    }
  });
});

// Welcome route
app.get('/', (req, res) => {
  res.json({
    message: 'Welcome to Google Drive Clone API',
    version: '1.0.0',
    docs: '/api/health',
    status: 'running'
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error'
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Route not found',
    requestedUrl: req.originalUrl
  });
});

const PORT = process.env.PORT || 5000;

// Test database connection before starting server
testConnection().then(connected => {
  if (!connected) {
    console.log('⚠️  Starting server without database connection...');
    console.log('💡 Run the setup script to create database tables');
  }
  
  app.listen(PORT, () => {
    console.log('\n' + '='.repeat(50));
    console.log('🚀 Google Drive Clone Backend');
    console.log('='.repeat(50));
    console.log(`🌐 Server: http://localhost:${PORT}`);
    console.log(`📊 Health: http://localhost:${PORT}/api/health`);
    console.log(`🔐 Auth: http://localhost:${PORT}/api/auth`);
    console.log(`📁 Files: http://localhost:${PORT}/api/files`);
    console.log('='.repeat(50));
    console.log('✅ Server started successfully!\n');
  });
});