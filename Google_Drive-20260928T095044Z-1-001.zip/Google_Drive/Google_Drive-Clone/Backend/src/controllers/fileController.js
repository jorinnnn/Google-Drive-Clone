﻿const { db, supabase } = require('../config/database');

// Get all files - SIMPLE VERSION (always returns mock data)
exports.getFiles = async (req, res) => {
  try {
    console.log('🔍 getFiles called for user:', req.userId);
    
    // Always return mock data for now
    const mockFiles = [
      {
        id: 'file-1-' + Date.now(),
        name: 'Welcome Document.pdf',
        size: 1048576, // 1MB
        type: 'pdf',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        user_id: req.userId,
        folder_id: null,
        is_public: false
      },
      {
        id: 'file-2-' + Date.now(),
        name: 'Sample Image.png',
        size: 524288, // 512KB
        type: 'image',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        user_id: req.userId,
        folder_id: null,
        is_public: false
      },
      {
        id: 'file-3-' + Date.now(),
        name: 'Budget Spreadsheet.xlsx',
        size: 2097152, // 2MB
        type: 'spreadsheet',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        user_id: req.userId,
        folder_id: null,
        is_public: false
      }
    ];
    
    console.log('📋 Returning mock files:', mockFiles.length);
    
    res.json({
      success: true,
      files: mockFiles,
      totalFiles: mockFiles.length,
      storageUsed: 3670016, // 3.5MB
      storageLimit: 16106127360, // 15GB
      message: 'Mock data for development'
    });
    
  } catch (error) {
    console.error('❌ getFiles error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error: ' + (error.message || 'Unknown error'),
      debug: {
        userId: req.userId,
        error: error.message
      }
    });
  }
};

// Other functions remain as before
exports.getFile = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Return mock file
    res.json({
      success: true,
      file: {
        id: id,
        name: 'Example File.txt',
        size: 1024,
        type: 'text',
        created_at: new Date().toISOString(),
        user_id: req.userId
      }
    });
  } catch (error) {
    console.error('Get file error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

exports.uploadFile = async (req, res) => {
  try {
    res.json({
      success: true,
      message: 'File upload endpoint ready'
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

exports.deleteFile = async (req, res) => {
  try {
    res.json({
      success: true,
      message: 'Delete endpoint ready'
    });
  } catch (error) {
    console.error('Delete error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

exports.downloadFile = async (req, res) => {
  try {
    res.json({
      success: true,
      message: 'Download endpoint ready'
    });
  } catch (error) {
    console.error('Download error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};
