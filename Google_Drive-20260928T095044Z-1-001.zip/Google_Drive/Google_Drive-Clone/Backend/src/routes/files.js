const express = require('express');
const router = express.Router();
const fileController = require('../controllers/fileController');
const auth = require('../middleware/auth');

// Apply authentication to all file routes
router.use(auth);

// File operations
router.post('/upload', fileController.uploadFile);
router.get('/', fileController.getFiles);
router.get('/:id', fileController.getFile);
router.delete('/:id', fileController.deleteFile);
router.get('/:id/download', fileController.downloadFile);

module.exports = router;