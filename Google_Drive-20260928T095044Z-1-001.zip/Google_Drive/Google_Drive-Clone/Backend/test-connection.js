const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

console.log('🔌 Testing Supabase Connection\n');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

console.log('Project URL:', supabaseUrl);
console.log('Anon Key:', supabaseKey ? '✓ Present' : '✗ Missing');

if (!supabaseUrl || !supabaseKey) {
  console.error('\n❌ Missing credentials in .env file');
  process.exit(1);
}

try {
  const supabase = createClient(supabaseUrl, supabaseKey);
  console.log('\n✅ Supabase client created');
  
  // Test connection
  console.log('\n📡 Testing database connection...');
  const { data, error } = await supabase.from('users').select('count').limit(1);
  
  if (error) {
    if (error.code === 'PGRST116') {
      console.log('✅ Connection successful!');
      console.log('ℹ️  Tables do not exist yet - this is normal for a new project');
    } else {
      console.error('❌ Connection error:', error.message);
      console.error('Error code:', error.code);
      console.error('\n💡 Troubleshooting:');
      console.error('1. Check if the URL and key are correct');
      console.error('2. Make sure your IP is allowed in Supabase network settings');
      console.error('3. Check if the project is active in Supabase');
    }
  } else {
    console.log('✅ Connection successful!');
    console.log('📊 Tables already exist');
  }
  
} catch (error) {
  console.error('\n❌ Failed to connect:', error.message);
}