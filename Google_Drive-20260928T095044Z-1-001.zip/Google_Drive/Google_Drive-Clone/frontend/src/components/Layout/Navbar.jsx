import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Search, 
  Bell, 
  User, 
  Settings, 
  LogOut, 
  ChevronDown,
  Menu,
  X,
  Cloud,
  Plus,
  Upload
} from 'lucide-react';
import { authService } from '../../services/auth';

const Navbar = ({ user, onUploadClick }) => {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleLogout = () => {
    authService.logout();
  };

  const handleSearch = (e) => {
    e.preventDefault();
    // Implement search functionality
    console.log('Searching for:', searchQuery);
  };

  const userInitial = user?.name?.charAt(0)?.toUpperCase() || 'U';

  return (
    <nav className="glass sticky top-0 z-50 border-b border-gray-200/50">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Left side - Logo and Menu */}
          <div className="flex items-center space-x-4">
            {/* Mobile menu button */}
            <button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="lg:hidden p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100/50 rounded-lg"
            >
              {showMobileMenu ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>

            {/* Logo */}
            <Link to="/dashboard" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <Cloud className="w-6 h-6 text-white" />
              </div>
              <div className="hidden md:block">
                <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  DriveCloud
                </h1>
                <p className="text-xs text-gray-500">Secure Cloud Storage</p>
              </div>
            </Link>
          </div>

          {/* Search bar - Desktop */}
          <div className="flex-1 max-w-2xl mx-4 hidden lg:block">
            <form onSubmit={handleSearch} className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search files, folders, and more..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/50 border border-gray-300/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-transparent backdrop-blur-sm"
              />
            </form>
          </div>

          {/* Right side - Actions */}
          <div className="flex items-center space-x-3">
            {/* Upload button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onUploadClick}
              className="btn-primary hidden md:flex items-center"
            >
              <Upload className="w-4 h-4 mr-2" />
              Upload
            </motion.button>

            {/* Quick actions */}
            <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100/50 rounded-xl">
              <Plus className="w-5 h-5" />
            </button>

            {/* Notifications */}
            <div className="relative">
              <button className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100/50 rounded-xl">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
            </div>

            {/* User menu */}
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center space-x-3 p-2 rounded-xl hover:bg-gray-100/50"
              >
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                  <span className="text-white font-semibold">{userInitial}</span>
                </div>
                <div className="hidden md:block text-left">
                  <p className="text-sm font-medium text-gray-900">{user?.name || 'User'}</p>
                  <p className="text-xs text-gray-500 truncate max-w-[150px]">
                    {user?.email || ''}
                  </p>
                </div>
                <ChevronDown className={`w-4 h-4 text-gray-500 transition-transform ${showUserMenu ? 'rotate-180' : ''}`} />
              </button>

              {/* Dropdown menu */}
              {showUserMenu && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setShowUserMenu(false)}
                  />
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute right-0 mt-2 w-72 bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-gray-200/50 py-2 z-50"
                  >
                    {/* User info */}
                    <div className="px-4 py-3 border-b border-gray-200/50">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                          <span className="text-white font-bold text-lg">{userInitial}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-gray-900 truncate">{user?.name}</p>
                          <p className="text-sm text-gray-500 truncate">{user?.email}</p>
                        </div>
                      </div>
                    </div>

                    {/* Menu items */}
                    <div className="py-2">
                      <Link
                        to="/profile"
                        className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-100/50"
                        onClick={() => setShowUserMenu(false)}
                      >
                        <User className="w-5 h-5" />
                        <span>My Profile</span>
                      </Link>
                      
                      <Link
                        to="/settings"
                        className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-100/50"
                        onClick={() => setShowUserMenu(false)}
                      >
                        <Settings className="w-5 h-5" />
                        <span>Settings</span>
                      </Link>

                      <div className="border-t border-gray-200/50 my-2"></div>

                      <button
                        onClick={handleLogout}
                        className="flex items-center space-x-3 px-4 py-3 text-red-600 hover:bg-red-50 w-full"
                      >
                        <LogOut className="w-5 h-5" />
                        <span>Sign out</span>
                      </button>
                    </div>

                    {/* Storage info */}
                    <div className="px-4 py-3 bg-gray-50/50 border-t border-gray-200/50">
                      <div className="text-sm">
                        <div className="flex justify-between mb-1">
                          <span className="text-gray-600">Storage</span>
                          <span className="font-medium text-gray-900">
                            {user?.storage_used 
                              ? `${(user.storage_used / (1024 * 1024 * 1024)).toFixed(2)} GB`
                              : '0 GB'} of 15 GB
                          </span>
                        </div>
                        <div className="progress-bar">
                          <div 
                            className="progress-fill" 
                            style={{ 
                              width: `${user?.storage_used ? (user.storage_used / (15 * 1024 * 1024 * 1024)) * 100 : 0}%` 
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Mobile search bar */}
        <div className="mt-4 lg:hidden">
          <form onSubmit={handleSearch} className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search files..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/50 border border-gray-300/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-transparent backdrop-blur-sm"
            />
          </form>
        </div>

        {/* Mobile menu */}
        {showMobileMenu && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:hidden mt-4 p-4 bg-white/95 backdrop-blur-xl rounded-2xl border border-gray-200/50"
          >
            <div className="space-y-3">
              <button
                onClick={onUploadClick}
                className="w-full btn-primary flex items-center justify-center"
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload Files
              </button>
              
              <div className="grid grid-cols-3 gap-2">
                <button className="p-3 bg-gray-100/50 hover:bg-gray-200/50 rounded-xl text-center">
                  <Plus className="w-5 h-5 mx-auto mb-1" />
                  <span className="text-xs">New</span>
                </button>
                <Link
                  to="/profile"
                  className="p-3 bg-gray-100/50 hover:bg-gray-200/50 rounded-xl text-center"
                  onClick={() => setShowMobileMenu(false)}
                >
                  <User className="w-5 h-5 mx-auto mb-1" />
                  <span className="text-xs">Profile</span>
                </Link>
                <Link
                  to="/settings"
                  className="p-3 bg-gray-100/50 hover:bg-gray-200/50 rounded-xl text-center"
                  onClick={() => setShowMobileMenu(false)}
                >
                  <Settings className="w-5 h-5 mx-auto mb-1" />
                  <span className="text-xs">Settings</span>
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;