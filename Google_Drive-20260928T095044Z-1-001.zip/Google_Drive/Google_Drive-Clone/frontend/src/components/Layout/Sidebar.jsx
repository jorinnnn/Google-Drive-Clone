import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Home,
  Folder,
  Star,
  Clock,
  Trash2,
  Share2,
  Users,
  Settings,
  HardDrive,
  ChevronRight,
  ChevronLeft,
  Cloud,
  Plus,
  Download,
  Upload
} from 'lucide-react';

const Sidebar = ({ onUploadClick, onCreateFolder }) => {
  const [collapsed, setCollapsed] = useState(false);

  const navItems = [
    { icon: Home, label: 'Home', path: '/dashboard' },
    { icon: Folder, label: 'My Drive', path: '/drive' },
    { icon: Star, label: 'Starred', path: '/starred' },
    { icon: Clock, label: 'Recent', path: '/recent' },
    { icon: Share2, label: 'Shared', path: '/shared' },
    { icon: Users, label: 'Shared with me', path: '/shared-with-me' },
    { icon: Trash2, label: 'Trash', path: '/trash' },
  ];

  const quickActions = [
    { icon: Upload, label: 'Upload', action: onUploadClick },
    { icon: Plus, label: 'New Folder', action: onCreateFolder },
    { icon: Download, label: 'Download All', action: () => console.log('Download all') },
  ];

  return (
    <aside className={`hidden lg:block bg-white/50 backdrop-blur-sm border-r border-gray-200/50 h-[calc(100vh-80px)] sticky top-20 transition-all duration-300 ${collapsed ? 'w-20' : 'w-64'}`}>
      <div className="p-6 h-full flex flex-col">
        {/* Collapse button */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="absolute -right-3 top-8 bg-white/80 backdrop-blur-sm border border-gray-300/50 rounded-full p-1.5 shadow-lg hover:shadow-xl transition-shadow"
        >
          {collapsed ? (
            <ChevronRight className="w-4 h-4 text-gray-600" />
          ) : (
            <ChevronLeft className="w-4 h-4 text-gray-600" />
          )}
        </button>

        {/* Quick Actions */}
        {!collapsed && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-4">
              Quick Actions
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {quickActions.map((action) => (
                <motion.button
                  key={action.label}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={action.action}
                  className="flex flex-col items-center justify-center p-3 bg-white/80 border border-gray-300/50 rounded-xl hover:border-blue-300 hover:shadow-md transition-all"
                >
                  <action.icon className="w-5 h-5 text-gray-600 mb-1" />
                  <span className="text-xs text-gray-600">{action.label}</span>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Navigation */}
        <nav className="flex-1">
          <h3 className={`text-xs font-semibold text-gray-500 uppercase tracking-wider mb-4 ${collapsed ? 'text-center' : ''}`}>
            {collapsed ? '•••' : 'Navigation'}
          </h3>
          <div className="space-y-1">
            {navItems.map((item) => (
              <NavLink
                key={item.label}
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center ${collapsed ? 'justify-center' : 'space-x-3'} px-4 py-3 rounded-xl transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-blue-500/10 to-purple-500/10 text-blue-600 border-l-4 border-blue-500'
                      : 'text-gray-700 hover:bg-gray-100/50 hover:text-gray-900'
                  }`
                }
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                {!collapsed && <span className="font-medium">{item.label}</span>}
              </NavLink>
            ))}
          </div>
        </nav>

        {/* Storage section - Only show when not collapsed */}
        {!collapsed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-auto pt-6 border-t border-gray-200/50"
          >
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <HardDrive className="w-4 h-4 text-gray-400" />
                  <span className="text-sm font-medium text-gray-700">Storage</span>
                </div>
                <span className="text-xs text-gray-500">83% used</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill w-[83%]" />
              </div>
              <p className="text-xs text-gray-500 mt-2">12.5 GB of 15 GB used</p>
            </div>

            {/* Upgrade button */}
            <button className="w-full mt-4 p-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl hover:from-blue-600 hover:to-purple-600 transition-all shadow-lg hover:shadow-xl">
              <div className="flex items-center justify-center space-x-2">
                <Cloud className="w-4 h-4" />
                <span className="font-medium">Upgrade Storage</span>
              </div>
            </button>

            {/* Settings link */}
            <NavLink
              to="/settings"
              className="flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-gray-100/50 rounded-xl mt-4"
            >
              <Settings className="w-5 h-5" />
              <span className="font-medium">Settings</span>
            </NavLink>
          </motion.div>
        )}

        {/* Collapsed view - Icons only */}
        {collapsed && (
          <div className="mt-auto space-y-2">
            <button className="w-full p-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl">
              <Cloud className="w-5 h-5 mx-auto" />
            </button>
            <button className="w-full p-3 text-gray-700 hover:bg-gray-100/50 rounded-xl">
              <Settings className="w-5 h-5 mx-auto" />
            </button>
          </div>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;