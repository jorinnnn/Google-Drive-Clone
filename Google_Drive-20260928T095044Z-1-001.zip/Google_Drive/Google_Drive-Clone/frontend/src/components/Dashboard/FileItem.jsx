import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  File,
  Folder,
  Image as ImageIcon,
  FileText,
  FileVideo,
  Music,
  Archive,
  Code,
  Download,
  Share2,
  MoreVertical,
  Star,
  Trash2,
  Copy,
  Eye,
  Edit,
  ExternalLink
} from 'lucide-react';
import { formatFileSize, formatDate, getFileIcon } from '../../utils/helpers';

const FileItem = ({ file, viewMode, isSelected, onSelect }) => {
  const [showActions, setShowActions] = useState(false);
  const [isStarred, setIsStarred] = useState(false);

  const { icon: fileIcon, color: iconColor, bg: iconBg } = getFileIcon(file.type, file.name);
  
  const iconMap = {
    Folder: <Folder className={`w-6 h-6 ${iconColor}`} />,
    Image: <ImageIcon className={`w-6 h-6 ${iconColor}`} />,
    FileText: <FileText className={`w-6 h-6 ${iconColor}`} />,
    Film: <FileVideo className={`w-6 h-6 ${iconColor}`} />,
    Music: <Music className={`w-6 h-6 ${iconColor}`} />,
    Archive: <Archive className={`w-6 h-6 ${iconColor}`} />,
    Code: <Code className={`w-6 h-6 ${iconColor}`} />,
    File: <File className={`w-6 h-6 ${iconColor}`} />
  };

  const IconComponent = iconMap[fileIcon] || <File className={`w-6 h-6 ${iconColor}`} />;

  const handleDownload = () => {
    console.log('Downloading:', file.id);
    // Implement download functionality
  };

  const handleDelete = () => {
    if (window.confirm(`Delete "${file.name}"?`)) {
      console.log('Deleting:', file.id);
      // Implement delete functionality
    }
  };

  const handleShare = () => {
    console.log('Sharing:', file.id);
    // Implement share functionality
  };

  if (viewMode === 'list') {
    return (
      <motion.div
        whileHover={{ scale: 1.005 }}
        className={`file-card ${isSelected ? 'border-blue-500 bg-blue-50/30' : ''}`}
      >
        <div className="grid grid-cols-12 gap-4 items-center">
          {/* Checkbox and Name */}
          <div className="col-span-5 flex items-center space-x-4">
            <input
              type="checkbox"
              checked={isSelected}
              onChange={onSelect}
              className="h-4 w-4 text-blue-600 rounded border-gray-300"
            />
            <div className="flex items-center space-x-3">
              <div className={`p-2 ${iconBg} rounded-lg`}>
                {IconComponent}
              </div>
              <div className="min-w-0">
                <p className="font-medium text-gray-900 truncate">{file.name}</p>
                <p className="text-sm text-gray-500">{file.owner || 'You'}</p>
              </div>
            </div>
          </div>

          {/* Size */}
          <div className="col-span-2">
            {file.type !== 'folder' ? (
              <p className="text-gray-700">{formatFileSize(file.size)}</p>
            ) : (
              <p className="text-gray-400">—</p>
            )}
          </div>

          {/* Modified Date */}
          <div className="col-span-3">
            <p className="text-gray-700">{formatDate(file.modified)}</p>
          </div>

          {/* Actions */}
          <div className="col-span-2">
            <div className="flex items-center justify-end space-x-2">
              <button
                onClick={() => setIsStarred(!isStarred)}
                className={`p-1.5 rounded-lg ${isStarred ? 'text-yellow-500 bg-yellow-50' : 'text-gray-400 hover:text-yellow-500 hover:bg-gray-100'}`}
                title={isStarred ? 'Unstar' : 'Star'}
              >
                <Star className="w-4 h-4" fill={isStarred ? 'currentColor' : 'none'} />
              </button>
              
              <div className="relative">
                <button
                  onClick={() => setShowActions(!showActions)}
                  className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg"
                >
                  <MoreVertical className="w-4 h-4" />
                </button>
                
                {showActions && (
                  <>
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setShowActions(false)}
                    />
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="absolute right-0 mt-2 w-48 bg-white/95 backdrop-blur-xl rounded-xl shadow-2xl border border-gray-200/50 py-1 z-50"
                    >
                      <button
                        onClick={handleDownload}
                        className="flex items-center space-x-3 w-full px-4 py-2.5 text-gray-700 hover:bg-gray-100/50"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download</span>
                      </button>
                      <button
                        onClick={handleShare}
                        className="flex items-center space-x-3 w-full px-4 py-2.5 text-gray-700 hover:bg-gray-100/50"
                      >
                        <Share2 className="w-4 h-4" />
                        <span>Share</span>
                      </button>
                      <button
                        className="flex items-center space-x-3 w-full px-4 py-2.5 text-gray-700 hover:bg-gray-100/50"
                      >
                        <Edit className="w-4 h-4" />
                        <span>Rename</span>
                      </button>
                      <button
                        className="flex items-center space-x-3 w-full px-4 py-2.5 text-gray-700 hover:bg-gray-100/50"
                      >
                        <Copy className="w-4 h-4" />
                        <span>Make a copy</span>
                      </button>
                      <div className="border-t border-gray-200/50 my-1"></div>
                      <button
                        onClick={handleDelete}
                        className="flex items-center space-x-3 w-full px-4 py-2.5 text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span>Move to trash</span>
                      </button>
                    </motion.div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }

  // Grid View
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={`file-card ${isSelected ? 'border-blue-500 bg-blue-50/30' : ''}`}
    >
      {/* Checkbox */}
      <div className="absolute top-3 right-3">
        <input
          type="checkbox"
          checked={isSelected}
          onChange={onSelect}
          className="h-4 w-4 text-blue-600 rounded border-gray-300"
        />
      </div>

      {/* File icon and actions */}
      <div className="flex items-start justify-between mb-4">
        <div className={`p-3 ${iconBg} rounded-xl`}>
          {IconComponent}
        </div>
        <div className="flex items-center space-x-1">
          <button
            onClick={() => setIsStarred(!isStarred)}
            className={`p-1.5 rounded-lg ${isStarred ? 'text-yellow-500' : 'text-gray-400 hover:text-yellow-500'}`}
            title={isStarred ? 'Unstar' : 'Star'}
          >
            <Star className="w-4 h-4" fill={isStarred ? 'currentColor' : 'none'} />
          </button>
          <button
            onClick={() => setShowActions(!showActions)}
            className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      {/* File name */}
      <h4 className="font-semibold text-gray-900 truncate mb-2">{file.name}</h4>
      
      {/* File info */}
      <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
        <span>{formatDate(file.modified)}</span>
        {file.type !== 'folder' && (
          <span>{formatFileSize(file.size)}</span>
        )}
      </div>
      
      {/* Quick actions */}
      <div className="flex items-center justify-between">
        <span className="text-xs text-gray-500">{file.owner || 'You'}</span>
        <div className="flex items-center space-x-2">
          {file.type !== 'folder' && (
            <button
              onClick={handleDownload}
              className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg"
              title="Download"
            >
              <Download className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={handleShare}
            className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg"
            title="Share"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Actions dropdown */}
      {showActions && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setShowActions(false)}
          />
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute right-3 top-12 w-48 bg-white/95 backdrop-blur-xl rounded-xl shadow-2xl border border-gray-200/50 py-1 z-50"
          >
            <button
              onClick={handleDownload}
              className="flex items-center space-x-3 w-full px-4 py-2.5 text-gray-700 hover:bg-gray-100/50"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </button>
            <button
              onClick={handleShare}
              className="flex items-center space-x-3 w-full px-4 py-2.5 text-gray-700 hover:bg-gray-100/50"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>
            <button
              className="flex items-center space-x-3 w-full px-4 py-2.5 text-gray-700 hover:bg-gray-100/50"
            >
              <Eye className="w-4 h-4" />
              <span>Preview</span>
            </button>
            <button
              className="flex items-center space-x-3 w-full px-4 py-2.5 text-gray-700 hover:bg-gray-100/50"
            >
              <Edit className="w-4 h-4" />
              <span>Rename</span>
            </button>
            <div className="border-t border-gray-200/50 my-1"></div>
            <button
              onClick={handleDelete}
              className="flex items-center space-x-3 w-full px-4 py-2.5 text-red-600 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete</span>
            </button>
          </motion.div>
        </>
      )}
    </motion.div>
  );
};

export default FileItem;