import React from 'react';
import { motion } from 'framer-motion';
import { 
  HardDrive, 
  Cloud, 
  Zap, 
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { 
  formatFileSize, 
  calculateStoragePercentage, 
  getStorageColor 
} from '../../utils/helpers';

const StorageStats = ({ user }) => {
  const storageUsed = user?.storage_used || 0;
  const storageLimit = user?.storage_limit || 15 * 1024 * 1024 * 1024; // 15GB in bytes
  const percentage = calculateStoragePercentage(storageUsed, storageLimit);
  const colorClass = getStorageColor(percentage);
  const formattedUsed = formatFileSize(storageUsed);
  const formattedTotal = formatFileSize(storageLimit);
  const remainingGB = ((storageLimit - storageUsed) / (1024 * 1024 * 1024)).toFixed(2);

  const getStorageMessage = () => {
    if (percentage < 50) return 'Plenty of storage available';
    if (percentage < 80) return 'Storage is getting used';
    if (percentage < 90) return 'Consider freeing up space';
    return 'Storage almost full!';
  };

  const getStorageIcon = () => {
    if (percentage < 50) return <Cloud className="w-6 h-6 text-green-500" />;
    if (percentage < 80) return <Zap className="w-6 h-6 text-yellow-500" />;
    return <AlertCircle className="w-6 h-6 text-red-500" />;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="card-hover mb-8"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        {/* Left side - Progress */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-xl">
                <HardDrive className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Storage Usage</h3>
                <p className="text-sm text-gray-600">{getStorageMessage()}</p>
              </div>
            </div>
            <div className="hidden md:block">
              {getStorageIcon()}
            </div>
          </div>

          {/* Progress bar */}
          <div className="mb-4">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-700">{formattedUsed} used</span>
              <span className="font-medium text-gray-900">{formattedTotal} total</span>
            </div>
            <div className="progress-bar">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${percentage}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className={`progress-fill ${colorClass}`}
              />
            </div>
            <div className="flex justify-between text-xs text-gray-500 mt-2">
              <span>0%</span>
              <span>100%</span>
            </div>
          </div>
        </div>

        {/* Right side - Stats */}
        <div className="md:w-64">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100/50 rounded-xl border border-blue-200/50">
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span className="text-xs font-medium text-blue-700">Used</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">{formattedUsed}</p>
              <p className="text-xs text-gray-600 mt-1">{percentage.toFixed(1)}% of total</p>
            </div>

            <div className="p-4 bg-gradient-to-br from-green-50 to-green-100/50 rounded-xl border border-green-200/50">
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-xs font-medium text-green-700">Available</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">{remainingGB} GB</p>
              <p className="text-xs text-gray-600 mt-1">Free space</p>
            </div>
          </div>

          {/* Quick tip */}
          {percentage > 70 && (
            <div className="mt-4 p-3 bg-gradient-to-r from-yellow-50 to-amber-50/50 border border-yellow-200/50 rounded-xl">
              <div className="flex items-start space-x-2">
                <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-yellow-700">
                  <span className="font-medium">Tip:</span> Delete unused files or upgrade storage for more space.
                </p>
              </div>
            </div>
          )}

          {/* Upgrade button */}
          {percentage > 80 && (
            <button className="w-full mt-4 btn-primary text-sm py-2">
              <TrendingUp className="w-4 h-4 mr-2" />
              Upgrade Storage
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default StorageStats;