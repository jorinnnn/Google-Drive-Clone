import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Upload,
  X,
  File,
  Image as ImageIcon,
  FileText,
  FileVideo,
  Folder,
  CheckCircle,
  AlertCircle,
  Loader2,
  Cloud,
  Trash2,
  ChevronRight
} from 'lucide-react';
import { formatFileSize } from '../../utils/helpers';

const UploadModal = ({ onClose, onUpload }) => {
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({});
  const [folderId, setFolderId] = useState(null);
  const [activeTab, setActiveTab] = useState('upload'); // 'upload' or 'progress'

  const onDrop = useCallback((acceptedFiles) => {
    const newFiles = acceptedFiles.map(file => ({
      file,
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
      type: file.type,
      progress: 0,
      status: 'pending',
      error: null
    }));
    setFiles(prev => [...prev, ...newFiles]);
    setActiveTab('progress');
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: true,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg'],
      'application/pdf': ['.pdf'],
      'text/*': ['.txt', '.md'],
      'application/msword': ['.doc', '.docx'],
      'application/vnd.ms-excel': ['.xls', '.xlsx'],
      'application/vnd.ms-powerpoint': ['.ppt', '.pptx'],
      'video/*': ['.mp4', '.avi', '.mov', '.mkv', '.webm'],
      'audio/*': ['.mp3', '.wav', '.ogg', '.m4a'],
      'application/zip': ['.zip', '.rar', '.7z'],
      'application/json': ['.json']
    },
    maxSize: 2 * 1024 * 1024 * 1024, // 2GB
  });

  const getFileIcon = (fileType) => {
    if (fileType.startsWith('image/')) {
      return <ImageIcon className="w-5 h-5 text-green-500" />;
    } else if (fileType.startsWith('video/')) {
      return <FileVideo className="w-5 h-5 text-red-500" />;
    } else if (fileType === 'application/pdf') {
      return <FileText className="w-5 h-5 text-red-400" />;
    } else if (fileType.includes('word') || fileType.includes('excel') || fileType.includes('powerpoint')) {
      return <FileText className="w-5 h-5 text-blue-500" />;
    } else if (fileType.startsWith('audio/')) {
      return <FileText className="w-5 h-5 text-purple-500" />;
    } else if (fileType.includes('zip') || fileType.includes('rar')) {
      return <FileText className="w-5 h-5 text-gray-600" />;
    } else {
      return <File className="w-5 h-5 text-gray-500" />;
    }
  };

  const removeFile = (id) => {
    setFiles(files.filter(file => file.id !== id));
    if (files.length === 1) {
      setActiveTab('upload');
    }
  };

  const clearAll = () => {
    setFiles([]);
    setActiveTab('upload');
  };

  const handleUpload = async () => {
    setUploading(true);
    
    for (const fileObj of files) {
      if (fileObj.status === 'pending') {
        try {
          // Update status to uploading
          setFiles(prev => prev.map(f => 
            f.id === fileObj.id ? { ...f, status: 'uploading' } : f
          ));

          // Simulate upload progress
          for (let i = 0; i <= 100; i += 10) {
            setUploadProgress(prev => ({
              ...prev,
              [fileObj.id]: i
            }));
            await new Promise(resolve => setTimeout(resolve, 100));
          }

          // Call actual upload function
          await onUpload(fileObj.file, folderId, (progress) => {
            setUploadProgress(prev => ({
              ...prev,
              [fileObj.id]: progress
            }));
          });

          // Update status to success
          setFiles(prev => prev.map(f => 
            f.id === fileObj.id ? { ...f, status: 'success' } : f
          ));
        } catch (error) {
          // Update status to error
          setFiles(prev => prev.map(f => 
            f.id === fileObj.id ? { ...f, status: 'error', error: error.message } : f
          ));
        }
      }
    }
    
    setUploading(false);
  };

  const pendingFiles = files.filter(f => f.status === 'pending');
  const uploadingFiles = files.filter(f => f.status === 'uploading');
  const completedFiles = files.filter(f => f.status === 'success' || f.status === 'error');
  const allCompleted = files.length > 0 && files.every(f => f.status !== 'pending' && f.status !== 'uploading');

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200/50">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Upload Files</h2>
              <p className="text-gray-600 mt-1">
                {activeTab === 'upload' ? 'Drag and drop or click to browse' : `Uploading ${files.length} file(s)`}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-700 rounded-full hover:bg-gray-100/50"
              disabled={uploading}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tabs */}
          <div className="border-b border-gray-200/50">
            <div className="flex px-6">
              <button
                onClick={() => setActiveTab('upload')}
                className={`px-4 py-3 font-medium text-sm border-b-2 transition-colors ${activeTab === 'upload' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
              >
                Select Files
              </button>
              {files.length > 0 && (
                <button
                  onClick={() => setActiveTab('progress')}
                  className={`px-4 py-3 font-medium text-sm border-b-2 transition-colors ${activeTab === 'progress' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
                >
                  Upload Progress
                  <span className="ml-2 px-2 py-0.5 text-xs rounded-full bg-blue-100 text-blue-600">
                    {files.length}
                  </span>
                </button>
              )}
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {activeTab === 'upload' ? (
              /* Upload Tab */
              <div>
                <div
                  {...getRootProps()}
                  className={`border-3 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all duration-300 ${
                    isDragActive
                      ? 'border-blue-500 bg-blue-50/50 scale-[1.02]'
                      : 'border-gray-300/50 hover:border-blue-400 hover:bg-gray-50/50'
                  }`}
                >
                  <input {...getInputProps()} />
                  <motion.div
                    animate={isDragActive ? { y: [-5, 5, -5] } : {}}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl mb-6"
                  >
                    <Upload className="w-10 h-10 text-blue-600" />
                  </motion.div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    {isDragActive ? '🎉 Drop files here!' : 'Drag & drop files here'}
                  </h3>
                  <p className="text-gray-600 mb-6">
                    or click to browse files from your computer
                  </p>
                  <div className="inline-flex items-center space-x-2 px-6 py-3 bg-gray-100/50 rounded-xl">
                    <Cloud className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">Supports images, documents, videos, and more</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-6">Maximum file size: 2GB</p>
                </div>

                {/* Recent folders */}
                <div className="mt-8">
                  <h4 className="text-sm font-semibold text-gray-700 mb-4">Upload to folder:</h4>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => setFolderId(null)}
                      className={`px-4 py-2 rounded-lg flex items-center space-x-2 ${!folderId ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                    >
                      <Folder className="w-4 h-4" />
                      <span>My Drive</span>
                    </button>
                    <button
                      onClick={() => setFolderId('photos')}
                      className={`px-4 py-2 rounded-lg flex items-center space-x-2 ${folderId === 'photos' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                    >
                      <ImageIcon className="w-4 h-4" />
                      <span>Photos</span>
                    </button>
                    <button
                      onClick={() => setFolderId('documents')}
                      className={`px-4 py-2 rounded-lg flex items-center space-x-2 ${folderId === 'documents' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                    >
                      <FileText className="w-4 h-4" />
                      <span>Documents</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              /* Progress Tab */
              <div>
                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-200/50">
                    <div className="text-2xl font-bold text-gray-900 mb-1">{files.length}</div>
                    <div className="text-sm text-blue-700">Total Files</div>
                  </div>
                  <div className="p-4 bg-green-50/50 rounded-xl border border-green-200/50">
                    <div className="text-2xl font-bold text-gray-900 mb-1">{completedFiles.length}</div>
                    <div className="text-sm text-green-700">Completed</div>
                  </div>
                  <div className="p-4 bg-yellow-50/50 rounded-xl border border-yellow-200/50">
                    <div className="text-2xl font-bold text-gray-900 mb-1">
                      {formatFileSize(files.reduce((acc, file) => acc + file.size, 0))}
                    </div>
                    <div className="text-sm text-yellow-700">Total Size</div>
                  </div>
                </div>

                {/* File list */}
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {files.map((fileObj) => (
                    <div
                      key={fileObj.id}
                      className="p-4 bg-gray-50/50 border border-gray-200/50 rounded-xl"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3 flex-1 min-w-0">
                          {getFileIcon(fileObj.type)}
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-gray-900 truncate">{fileObj.name}</p>
                            <p className="text-sm text-gray-500">
                              {formatFileSize(fileObj.size)}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          {/* Progress/Status */}
                          {fileObj.status === 'uploading' && (
                            <div className="w-32">
                              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{ width: `${uploadProgress[fileObj.id] || 0}%` }}
                                  className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"
                                />
                              </div>
                              <p className="text-xs text-gray-500 mt-1 text-right">
                                {uploadProgress[fileObj.id] || 0}%
                              </p>
                            </div>
                          )}
                          
                          {fileObj.status === 'success' && (
                            <CheckCircle className="w-5 h-5 text-green-500" />
                          )}
                          
                          {fileObj.status === 'error' && (
                            <AlertCircle className="w-5 h-5 text-red-500" />
                          )}
                          
                          <button
                            onClick={() => removeFile(fileObj.id)}
                            className="p-1.5 text-gray-400 hover:text-red-500"
                            disabled={fileObj.status === 'uploading'}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      
                      {fileObj.error && (
                        <p className="mt-2 text-xs text-red-600">{fileObj.error}</p>
                      )}
                    </div>
                  ))}
                </div>

                {/* Empty state */}
                {files.length === 0 && (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 mx-auto mb-4 bg-gray-100/50 rounded-full flex items-center justify-center">
                      <File className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No files selected</h3>
                    <p className="text-gray-600">Go back to select files to upload</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between p-6 border-t border-gray-200/50">
            <div className="flex items-center space-x-4">
              {activeTab === 'progress' && files.length > 0 && (
                <button
                  onClick={clearAll}
                  className="px-4 py-2 text-gray-700 hover:text-gray-900 font-medium"
                  disabled={uploading}
                >
                  Clear All
                </button>
              )}
              
              {activeTab === 'upload' && files.length > 0 && (
                <button
                  onClick={() => setActiveTab('progress')}
                  className="flex items-center space-x-2 px-4 py-2 text-blue-600 hover:text-blue-800 font-medium"
                >
                  <span>View Selected ({files.length})</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              )}
            </div>
            
            <div className="flex items-center space-x-3">
              <button
                onClick={onClose}
                className="px-6 py-3 text-gray-700 hover:text-gray-900 font-medium"
                disabled={uploading}
              >
                Cancel
              </button>
              
              {files.length > 0 && (
                <button
                  onClick={handleUpload}
                  disabled={uploading || allCompleted}
                  className="btn-primary flex items-center"
                >
                  {uploading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Uploading...
                    </>
                  ) : allCompleted ? (
                    <>
                      <CheckCircle className="w-5 h-5 mr-2" />
                      All Uploaded
                    </>
                  ) : (
                    <>
                      <Upload className="w-5 h-5 mr-2" />
                      Upload {files.length > 0 ? `(${files.length})` : ''}
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default UploadModal;