import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Grid,
  List,
  Search,
  Filter,
  Download,
  Share2,
  Trash2,
  MoreVertical,
  FolderPlus,
  FileUp,
  RefreshCw,
  File,
  Folder,
  Image,
  FileText,
  FileVideo,
  Music,
  Archive,
  Code
} from 'lucide-react';
import FileItem from './FileItem';
import { formatFileSize, formatDate } from '../../utils/helpers';

const FileBrowser = ({ files, loading, onRefresh, onUpload, onCreateFolder }) => {
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
  const [sortBy, setSortBy] = useState('date'); // 'name', 'date', 'size', 'type'
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFiles, setSelectedFiles] = useState(new Set());

  // Mock data for demo - replace with actual API data
  const mockFiles = [
    {
      id: '1',
      name: 'Project Report.pdf',
      type: 'application/pdf',
      size: 2048000,
      modified: new Date(Date.now() - 3600000).toISOString(),
      owner: 'You'
    },
    {
      id: '2',
      name: 'Vacation Photos',
      type: 'folder',
      size: 0,
      modified: new Date(Date.now() - 86400000).toISOString(),
      owner: 'You'
    },
    {
      id: '3',
      name: 'Design Mockup.png',
      type: 'image/png',
      size: 5120000,
      modified: new Date(Date.now() - 172800000).toISOString(),
      owner: 'You'
    },
    {
      id: '4',
      name: 'Meeting Recording.mp4',
      type: 'video/mp4',
      size: 25600000,
      modified: new Date(Date.now() - 259200000).toISOString(),
      owner: 'You'
    },
    {
      id: '5',
      name: 'Financial Data.xlsx',
      type: 'application/vnd.ms-excel',
      size: 1024000,
      modified: new Date(Date.now() - 345600000).toISOString(),
      owner: 'You'
    },
    {
      id: '6',
      name: 'Code Repository',
      type: 'folder',
      size: 0,
      modified: new Date(Date.now() - 432000000).toISOString(),
      owner: 'You'
    },
    {
      id: '7',
      name: 'Background Music.mp3',
      type: 'audio/mpeg',
      size: 8192000,
      modified: new Date(Date.now() - 518400000).toISOString(),
      owner: 'You'
    },
    {
      id: '8',
      name: 'Archive Backup.zip',
      type: 'application/zip',
      size: 15360000,
      modified: new Date(Date.now() - 604800000).toISOString(),
      owner: 'You'
    }
  ];

  const displayedFiles = files && files.length > 0 ? files : mockFiles;

  const filteredFiles = displayedFiles.filter(file =>
    file.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedFiles = [...filteredFiles].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'size':
        return b.size - a.size;
      case 'type':
        return a.type.localeCompare(b.type);
      case 'date':
      default:
        return new Date(b.modified) - new Date(a.modified);
    }
  });

  const handleSelectFile = (fileId) => {
    const newSelected = new Set(selectedFiles);
    if (newSelected.has(fileId)) {
      newSelected.delete(fileId);
    } else {
      newSelected.add(fileId);
    }
    setSelectedFiles(newSelected);
  };

  const handleSelectAll = () => {
    if (selectedFiles.size === sortedFiles.length) {
      setSelectedFiles(new Set());
    } else {
      setSelectedFiles(new Set(sortedFiles.map(file => file.id)));
    }
  };

  const handleBulkDelete = () => {
    if (selectedFiles.size > 0) {
      if (window.confirm(`Delete ${selectedFiles.size} selected file(s)?`)) {
        // Implement bulk delete
        console.log('Deleting files:', Array.from(selectedFiles));
        setSelectedFiles(new Set());
      }
    }
  };

  const handleBulkDownload = () => {
    if (selectedFiles.size > 0) {
      console.log('Downloading files:', Array.from(selectedFiles));
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="card animate-pulse">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gray-200 rounded-xl"></div>
              <div className="flex-1">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-gray-900">My Files</h2>
          <span className="badge badge-primary">
            {sortedFiles.length} {sortedFiles.length === 1 ? 'item' : 'items'}
          </span>
          {selectedFiles.size > 0 && (
            <span className="badge bg-blue-500/10 text-blue-700 border border-blue-500/20">
              {selectedFiles.size} selected
            </span>
          )}
        </div>

        <div className="flex items-center space-x-3">
          {/* Bulk actions */}
          {selectedFiles.size > 0 && (
            <div className="flex items-center space-x-2 mr-4">
              <button
                onClick={handleBulkDownload}
                className="p-2 text-blue-600 hover:bg-blue-50 rounded-xl"
                title="Download selected"
              >
                <Download className="w-5 h-5" />
              </button>
              <button
                onClick={handleBulkDelete}
                className="p-2 text-red-600 hover:bg-red-50 rounded-xl"
                title="Delete selected"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          )}

          {/* View mode toggle */}
          <div className="flex items-center bg-white/50 border border-gray-300/50 rounded-xl overflow-hidden">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-3 ${viewMode === 'grid' ? 'bg-gray-100/50' : ''}`}
              title="Grid view"
            >
              <Grid className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-3 ${viewMode === 'list' ? 'bg-gray-100/50' : ''}`}
              title="List view"
            >
              <List className="w-5 h-5" />
            </button>
          </div>

          {/* Refresh button */}
          <button
            onClick={onRefresh}
            className="p-3 text-gray-600 hover:text-gray-900 hover:bg-gray-100/50 rounded-xl"
            title="Refresh"
          >
            <RefreshCw className="w-5 h-5" />
          </button>

          {/* Sort dropdown */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="input-field py-2 pl-10 pr-4"
          >
            <option value="date">Sort by Date</option>
            <option value="name">Sort by Name</option>
            <option value="size">Sort by Size</option>
            <option value="type">Sort by Type</option>
          </select>
        </div>
      </div>

      {/* Search and actions */}
      <div className="flex flex-col md:flex-row md:items-center gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search files by name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input-field pl-12"
          />
        </div>
        
        <div className="flex items-center space-x-3">
          <button
            onClick={onUpload}
            className="btn-primary flex items-center"
          >
            <FileUp className="w-5 h-5 mr-2" />
            Upload
          </button>
          <button
            onClick={onCreateFolder}
            className="btn-secondary flex items-center"
          >
            <FolderPlus className="w-5 h-5 mr-2" />
            New Folder
          </button>
        </div>
      </div>

      {/* List header for list view */}
      {viewMode === 'list' && (
        <div className="bg-gray-50/50 border border-gray-200/50 rounded-xl p-4 hidden md:block">
          <div className="grid grid-cols-12 gap-4 text-sm font-medium text-gray-600">
            <div className="col-span-5 flex items-center">
              <input
                type="checkbox"
                checked={selectedFiles.size === sortedFiles.length && sortedFiles.length > 0}
                onChange={handleSelectAll}
                className="h-4 w-4 text-blue-600 rounded mr-4"
              />
              Name
            </div>
            <div className="col-span-2">Size</div>
            <div className="col-span-3">Modified</div>
            <div className="col-span-2">Actions</div>
          </div>
        </div>
      )}

      {/* Files display */}
      <AnimatePresence>
        {sortedFiles.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center">
              <File className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No files found</h3>
            <p className="text-gray-600 mb-8">
              {searchQuery ? 'Try a different search term' : 'Upload your first file to get started'}
            </p>
            <button
              onClick={onUpload}
              className="btn-primary inline-flex items-center"
            >
              <FileUp className="w-5 h-5 mr-2" />
              Upload Files
            </button>
          </motion.div>
        ) : viewMode === 'grid' ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          >
            {sortedFiles.map((file, index) => (
              <motion.div
                key={file.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
              >
                <FileItem
                  file={file}
                  viewMode={viewMode}
                  isSelected={selectedFiles.has(file.id)}
                  onSelect={() => handleSelectFile(file.id)}
                />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-2"
          >
            {sortedFiles.map((file, index) => (
              <motion.div
                key={file.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
              >
                <FileItem
                  file={file}
                  viewMode={viewMode}
                  isSelected={selectedFiles.has(file.id)}
                  onSelect={() => handleSelectFile(file.id)}
                />
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default FileBrowser;