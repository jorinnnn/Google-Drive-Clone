import api from './api';

export const fileService = {
  getFiles: async (folderId = null) => {
    try {
      const params = folderId ? { folderId } : {};
      return await api.get('/files', { params });
    } catch (error) {
      throw error;
    }
  },

  uploadFile: async (file, folderId = null, onProgress) => {
    try {
      const formData = new FormData();
      formData.append('file', file);
      if (folderId) {
        formData.append('folderId', folderId);
      }
      
      const response = await api.post('/files/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          if (onProgress && progressEvent.total) {
            const percentCompleted = Math.round(
              (progressEvent.loaded * 100) / progressEvent.total
            );
            onProgress(percentCompleted);
          }
        },
      });
      
      return response;
    } catch (error) {
      throw error;
    }
  },

  createFolder: async (name, parentId = null) => {
    try {
      return await api.post('/files/folder', { name, parentId });
    } catch (error) {
      throw error;
    }
  },

  deleteFile: async (fileId) => {
    try {
      return await api.delete(`/files/${fileId}`);
    } catch (error) {
      throw error;
    }
  },

  downloadFile: async (fileId) => {
    try {
      window.open(`/api/files/${fileId}/download`, '_blank');
      return { success: true };
    } catch (error) {
      throw error;
    }
  },

  getFileDetails: async (fileId) => {
    try {
      return await api.get(`/files/${fileId}`);
    } catch (error) {
      throw error;
    }
  }
};