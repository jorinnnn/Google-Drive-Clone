export const formatFileSize = (bytes) => {
  if (bytes === 0 || !bytes) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
};

export const formatDate = (dateString) => {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now - date;
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays === 0) {
    return 'Today';
  } else if (diffDays === 1) {
    return 'Yesterday';
  } else if (diffDays < 7) {
    return `${diffDays} days ago`;
  } else {
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
    });
  }
};

export const getFileIcon = (fileType, fileName) => {
  if (fileType === 'folder') {
    return { icon: 'Folder', color: 'text-yellow-500', bg: 'bg-yellow-500/10' };
  }

  const extension = fileName.split('.').pop().toLowerCase();
  
  const iconMap = {
    // Images
    jpg: { icon: 'Image', color: 'text-green-500', bg: 'bg-green-500/10' },
    jpeg: { icon: 'Image', color: 'text-green-500', bg: 'bg-green-500/10' },
    png: { icon: 'Image', color: 'text-green-500', bg: 'bg-green-500/10' },
    gif: { icon: 'Image', color: 'text-green-500', bg: 'bg-green-500/10' },
    svg: { icon: 'Image', color: 'text-green-500', bg: 'bg-green-500/10' },
    webp: { icon: 'Image', color: 'text-green-500', bg: 'bg-green-500/10' },
    
    // Documents
    pdf: { icon: 'FileText', color: 'text-red-500', bg: 'bg-red-500/10' },
    doc: { icon: 'FileText', color: 'text-blue-500', bg: 'bg-blue-500/10' },
    docx: { icon: 'FileText', color: 'text-blue-500', bg: 'bg-blue-500/10' },
    txt: { icon: 'FileText', color: 'text-gray-500', bg: 'bg-gray-500/10' },
    
    // Spreadsheets
    xls: { icon: 'Table', color: 'text-green-600', bg: 'bg-green-600/10' },
    xlsx: { icon: 'Table', color: 'text-green-600', bg: 'bg-green-600/10' },
    csv: { icon: 'Table', color: 'text-green-600', bg: 'bg-green-600/10' },
    
    // Presentations
    ppt: { icon: 'Presentation', color: 'text-orange-500', bg: 'bg-orange-500/10' },
    pptx: { icon: 'Presentation', color: 'text-orange-500', bg: 'bg-orange-500/10' },
    
    // Videos
    mp4: { icon: 'Film', color: 'text-purple-500', bg: 'bg-purple-500/10' },
    avi: { icon: 'Film', color: 'text-purple-500', bg: 'bg-purple-500/10' },
    mov: { icon: 'Film', color: 'text-purple-500', bg: 'bg-purple-500/10' },
    mkv: { icon: 'Film', color: 'text-purple-500', bg: 'bg-purple-500/10' },
    
    // Audio
    mp3: { icon: 'Music', color: 'text-pink-500', bg: 'bg-pink-500/10' },
    wav: { icon: 'Music', color: 'text-pink-500', bg: 'bg-pink-500/10' },
    m4a: { icon: 'Music', color: 'text-pink-500', bg: 'bg-pink-500/10' },
    
    // Archives
    zip: { icon: 'Archive', color: 'text-gray-600', bg: 'bg-gray-600/10' },
    rar: { icon: 'Archive', color: 'text-gray-600', bg: 'bg-gray-600/10' },
    '7z': { icon: 'Archive', color: 'text-gray-600', bg: 'bg-gray-600/10' },
    
    // Code
    js: { icon: 'Code', color: 'text-yellow-600', bg: 'bg-yellow-600/10' },
    jsx: { icon: 'Code', color: 'text-yellow-600', bg: 'bg-yellow-600/10' },
    ts: { icon: 'Code', color: 'text-blue-600', bg: 'bg-blue-600/10' },
    tsx: { icon: 'Code', color: 'text-blue-600', bg: 'bg-blue-600/10' },
    html: { icon: 'Code', color: 'text-orange-600', bg: 'bg-orange-600/10' },
    css: { icon: 'Code', color: 'text-blue-500', bg: 'bg-blue-500/10' },
    py: { icon: 'Code', color: 'text-blue-700', bg: 'bg-blue-700/10' },
    json: { icon: 'Code', color: 'text-gray-700', bg: 'bg-gray-700/10' },
  };

  return iconMap[extension] || { icon: 'File', color: 'text-gray-500', bg: 'bg-gray-500/10' };
};

export const calculateStoragePercentage = (used, total) => {
  if (!total || total === 0) return 0;
  return Math.min(100, (used / total) * 100);
};

export const getStorageColor = (percentage) => {
  if (percentage < 70) return 'from-green-500 to-emerald-500';
  if (percentage < 85) return 'from-yellow-500 to-amber-500';
  return 'from-red-500 to-rose-500';
};

export const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

export const validatePassword = (password) => {
  return password.length >= 6;
};